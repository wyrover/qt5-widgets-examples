#ifndef widget01_h__
#define widget01_h__

#include <QWidget>

class Widget01 : public QWidget
{
    Q_OBJECT
public:
    Widget01(QWidget *parent = 0);
    ~Widget01();
};


#endif // widget01_h__