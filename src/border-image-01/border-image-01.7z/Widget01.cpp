#include "widget01.h"




Widget01::Widget01(QWidget *parent)
    : QWidget(parent)
{
  

}

Widget01::~Widget01()
{
   

}