#ifndef MAINFORM_H
#define MAINFORM_H

#include "drop_shadow_widget.h"
#include <QWidget>
#include <QDialog>
class QHBoxLayout;
class QVBoxLayout;
class QFrame;
class QToolButton;
class QPushButton;
class LoginForm;

class MainForm : public DropShadowWidget
{
    Q_OBJECT

public:
    explicit MainForm(QDialog *parent = 0);
    ~MainForm();

protected:
    virtual void mousePressEvent(QMouseEvent *event);
    virtual void mouseMoveEvent(QMouseEvent *event);
    virtual void mouseReleaseEvent(QMouseEvent *event);

    

    virtual bool eventFilter(QObject *watched, QEvent *event);
    virtual bool nativeEvent(const QByteArray &eventType, void *message, long *result);
private slots:
    void onToolbarClicked(bool checked);
    void changeCenterWidget(bool event);
    void onMaximize_button_clicked(bool checked);

private:
    void create_svg_toolbar();
    QFrame* create_top_nav();
    QFrame* create_nav();
    QFrame* create_nav2();
    QFrame* create_sub_main();

    QToolButton* createSidebarButton(const QString& iconPath, const QString& title, const QString& object_name);
private:
    QHBoxLayout* layout_;
    QVBoxLayout* nav_layout_;
    QFrame* nav2_;

    QToolButton* activeButton_;
    QToolButton* tool_button_parameter_;
    QToolButton* tool_button_assets_;
    QToolButton* tool_button_log_;
    QToolButton* tool_button_logout_;


    QPushButton* maximize_button_;

    bool		mMoveing;
    QPoint	    mMovePosition;

    QRect       normal_rect_;

    LoginForm*  loginForm_;

};

#endif // MAINFORM_H
