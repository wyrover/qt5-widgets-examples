#include "mainform.h"
#include "loginform.h"
#include <QApplication>
#include <QFile>
#include <QtPlugin>

#ifdef WIN32
#include <windows.h>
#include <stdio.h>
#endif


#if defined(Q_OS_WIN32)
Q_IMPORT_PLUGIN(QWindowsIntegrationPlugin)
#elif defined(Q_OS_MAC)
Q_IMPORT_PLUGIN(QCocoaIntegrationPlugin)
#endif




Q_IMPORT_PLUGIN(QICOPlugin)
//Q_IMPORT_PLUGIN(QJpegPlugin)
//Q_IMPORT_PLUGIN(QGifPlugin)
//Q_IMPORT_PLUGIN(QTgaPlugin)
//Q_IMPORT_PLUGIN(QSvgPlugin)
Q_IMPORT_PLUGIN(QSvgIconPlugin)

int main(int argc, char *argv[])
{
#ifdef _DEBUG

#ifdef WIN32

    // detach from the current console window

    // if launched from a console window, that will still run waiting for the new console (below) to close

    // it is useful to detach from Qt Creator's <Application output> panel

    FreeConsole();

    // create a separate new console window

    AllocConsole();

    // attach the new console to this application's process

    AttachConsole(GetCurrentProcessId());

    SetConsoleOutputCP(65001);

    // reopen the std I/O streams to redirect I/O to the new console

    freopen("CON", "w", stdout);

    freopen("CON", "w", stderr);

    freopen("CON", "r", stdin);

#endif

#endif

    QApplication a(argc, argv);



    QFile qss("styles/default.qss");  
    qss.open(QFile::ReadOnly);
    // Apply the loaded stylesheet
    QString style(qss.readAll());
    a.setStyleSheet(style);
    qss.close();
    


    a.setFont(QFont("Microsoft Yahei", 9));

    MainForm w;
    w.show();

    //LoginForm w;
    //w.show();

    return a.exec();
}
