﻿#if defined (_MSC_VER) && (_MSC_VER >=1600)
#pragma execution_character_set("utf-8")
#endif


#include "mainform.h"
#include "ui_mainform.h"
#include "maximize_button.h"
#include "loginform.h"
#include <QToolBar>
#include <QHBoxLayout>
#include <QVBoxLayout>
#include <QListWidget>
#include <QFrame>
#include <QLabel>
#include <QPushButton>
#include <QComboBox>
#include <QCheckBox>
#include <QSpinBox>
#include <QApplication>
#include <QDesktopWidget>
#include <QMouseEvent>
#include <QToolButton>
#include <QTreeWidget>
#include <QGridLayout>
#include <QDebug>
#include <qmath.h>

#ifdef Q_OS_WIN
#include <qt_windows.h>
#include <Windowsx.h>
#endif

MainForm::MainForm(QDialog *parent) :
    DropShadowWidget(parent), mMoveing(false)
{
   
    setWindowFlags(Qt::FramelessWindowHint);   
   
  

    layout_ = new QHBoxLayout;  


    QVBoxLayout* main_layout = new QVBoxLayout;
    QFrame* mainWidget = new QFrame;
    mainWidget->setObjectName("mainWidget");   
    mainWidget->setLayout(main_layout); 
   

    main_layout->addWidget(create_top_nav());
    main_layout->addWidget(create_sub_main());
    main_layout->setSpacing(0);
    main_layout->setContentsMargins(0, 0, 0, 0);   
    

    layout_->addWidget(create_nav());
    layout_->addWidget(mainWidget);

    layout_->setSpacing(0);
    layout_->setContentsMargins(6, 6, 6, 6);

    //m_mainLayout->setContentsMargins(9, 8, 9, 5);

    setLayout(layout_);

    resize(1920, 1040);
    move((QApplication::desktop()->width() - width()) / 2, (QApplication::desktop()->height() - height()) / 2);


    loginForm_ = new LoginForm;    
    loginForm_->move(QPoint(this->pos().x() + ((this->width() - loginForm_->width()) / 2), this->pos().y() + ((this->height() - loginForm_->height()) / 2)));
    loginForm_->show();
}

MainForm::~MainForm()
{
    
}

void MainForm::mousePressEvent(QMouseEvent *event)
{
    mMoveing = true;    

    //记录下鼠标相对于窗口的位置
    //event->globalPos()鼠标按下时，鼠标相对于整个屏幕位置
    //pos() this->pos()鼠标按下时，窗口相对于整个屏幕位置
    mMovePosition = event->globalPos() - pos();
    return QWidget::mousePressEvent(event);

}

void MainForm::mouseMoveEvent(QMouseEvent *event)
{   
    //(event->buttons() && Qt::LeftButton)按下是左键
    //鼠标移动事件需要移动窗口，窗口移动到哪里呢？就是要获取鼠标移动中，窗口在整个屏幕的坐标，然后move到这个坐标，怎么获取坐标？
    //通过事件event->globalPos()知道鼠标坐标，鼠标坐标减去鼠标相对于窗口位置，就是窗口在整个屏幕的坐标
    if (mMoveing && (event->buttons() && Qt::LeftButton)
        && (event->globalPos() - mMovePosition).manhattanLength() > QApplication::startDragDistance()) {  

        move(event->globalPos() - mMovePosition);
        mMovePosition = event->globalPos() - pos();
    }
    return QWidget::mouseMoveEvent(event);

}

void MainForm::mouseReleaseEvent(QMouseEvent *event)
{
    mMoveing = false;

}



bool MainForm::eventFilter(QObject *watched, QEvent *event)
{
    if (event->type() == QEvent::MouseButtonDblClick) {
        this->onMaximize_button_clicked(false);
        return true;
    }
    return QObject::eventFilter(watched, event);
}

bool MainForm::nativeEvent(const QByteArray &eventType, void *message, long *result)
{
    int m_nBorder = 5;
    Q_UNUSED(eventType)
        MSG *param = static_cast<MSG *>(message);

    switch (param->message) {
        case WM_NCHITTEST:
        {
            int nX = GET_X_LPARAM(param->lParam) - this->geometry().x();
            int nY = GET_Y_LPARAM(param->lParam) - this->geometry().y();

            //// if mouse in the child Qwidget of mainfrme, we should not handle it
            //if (childAt(nX, nY) != NULL)
            //	return QWidget::nativeEvent(eventType, message, result);

            *result = HTCAPTION;

            // if mouse in the border of mainframe,we zoom mainframe
            if ((nX > 0) && (nX < m_nBorder))
                *result = HTLEFT;

            if ((nX > this->width() - m_nBorder) && (nX < this->width()))
                *result = HTRIGHT;

            if ((nY > 0) && (nY < m_nBorder))
                *result = HTTOP;

            if ((nY > this->height() - m_nBorder) && (nY < this->height()))
                *result = HTBOTTOM;

            if ((nX > 0) && (nX < m_nBorder) && (nY > 0)
                && (nY < m_nBorder))
                *result = HTTOPLEFT;

            if ((nX > this->width() - m_nBorder) && (nX < this->width())
                && (nY > 0) && (nY < m_nBorder))
                *result = HTTOPRIGHT;

            if ((nX > 0) && (nX < m_nBorder)
                && (nY > this->height() - m_nBorder) && (nY < this->height()))
                *result = HTBOTTOMLEFT;

            if ((nX > this->width() - m_nBorder) && (nX < this->width())
                && (nY > this->height() - m_nBorder) && (nY < this->height()))
                *result = HTBOTTOMRIGHT;

            if (*result == HTCAPTION) {
                return false;
            }
            return true;
        }
    }
    return QWidget::nativeEvent(eventType, message, result);
}

void MainForm::onToolbarClicked(bool checked)
{

}

void MainForm::changeCenterWidget(bool event)
{
    Q_UNUSED(event);
    QString sender = QObject::sender()->objectName();


    if (sender.compare("tool_button_Logout") == 0) {
        return;
    }


    if (activeButton_ != nullptr) {
        activeButton_->setChecked(false);
        activeButton_->setIcon(QIcon(activeButton_->property("default_icon").toString()));        
    }

    activeButton_ = static_cast<QToolButton*>(QObject::sender());
    activeButton_->setChecked(true);

    QString hover_icon = activeButton_->property("hover_icon").toString();
    if (!hover_icon.isEmpty())
        activeButton_->setIcon(QIcon(hover_icon));
    else
        activeButton_->setIcon(QIcon(activeButton_->property("default_icon").toString()));

    /* Remove all views from the stack if something is available */
    /*while (_stackedWidget->count() > 0) {
    pop();
    }*/

    /* if (sender.compare("首页") == 0) {
         _stackedWidget->setCurrentIndex(0);
     }
     else if (sender.compare("tool_button_Parameter") == 0) {
         ArgsPage* page = (ArgsPage*)showPage(_stackedWidget, "ArgsPage");
     }
     else if (sender.compare("tool_button_Assets") == 0) {
         showPage(_stackedWidget, "PlatformPage");
     }
     else if (sender.compare("tool_button_Log") == 0) {
         showPage(_stackedWidget, "LogPage");
     }
     else if (sender.compare("tool_button_Upgrade") == 0) {
         QDesktopServices::openUrl(ArgsService::instance()->getUpgradeUrl());
     }
     else if (sender.compare("tool_button_Logout") == 0) {

         if (ArgsService::instance()->robotIsRunning()) {

             int reply;
             reply = QMessageBox::question(this, tr("提示"), tr("机器人正在运行，你真的要注销吗？"), tr("是"), tr("否"));

             if (reply == 0) {
                 ArgsService::instance()->appStop();
                 showLoginForm();
             }

         }
         else {
             int reply;
             reply = QMessageBox::question(this, tr("提示"), tr("你真的要注销吗？"), tr("是"), tr("否"));

             if (reply == 0) {
                 showLoginForm();
             }
         }
     }*/
}

void MainForm::onMaximize_button_clicked(bool checked)
{
    if (isMaximized()) {
        showNormal();
        maximize_button_->setIcon(QIcon(":/images/morebig_icon.svg"));
       
    }
    else {
        showMaximized();
        maximize_button_->setIcon(QIcon(":/images/morelittle_icon.svg"));
    }
}

void MainForm::create_svg_toolbar()
{
    auto toolbar = new QToolBar(this);
    toolbar->addAction(QIcon(":/svg/material_icons/ic_apps_white_48px.svg"), tr("Refresh"));
    toolbar->addSeparator();
    toolbar->addAction(QIcon(":/svg/material_icons/ic_bug_report_white_48px.svg"), tr("Install"));
    toolbar->addAction(QIcon(":/svg/material_icons/ic_build_white_48px.svg"), tr("Uninstall"));
    toolbar->addSeparator();
    toolbar->addAction(QIcon(":/svg/material_icons/ic_create_white_48px.svg"), tr("Enable"));
    toolbar->addAction(QIcon(":/svg/material_icons/ic_format_align_left_white_48px.svg"), tr("Disable"));
    toolbar->addSeparator();
    toolbar->addAction(QIcon(":/svg/material_icons/ic_help_white_48px.svg"), tr("Extract APK"));
    layout_->addWidget(toolbar);
}

QFrame* MainForm::create_top_nav()
{
    QFrame* topNav = new QFrame;
    topNav->setObjectName("topNav");

    auto layout = new QHBoxLayout;
    layout->setDirection(QBoxLayout::RightToLeft);


    auto close_button = new MaximizeButton;
    close_button->setObjectName("close_button");
    close_button->setFlat(true);
    close_button->setFocusPolicy(Qt::NoFocus);
    connect(close_button, SIGNAL(clicked(bool)), qApp, SLOT(quit()));
    /*connect(close_button, &QPushButton::enterEvent, [=](QEvent* event) {
        close_button->setIcon(QIcon(":/images/closs_icon_1.svg"));
    });

    connect(close_button, &QPushButton::leaveEvent, [=](QEvent* event) {
        close_button->setIcon(QIcon(":/images/closs_icon.svg"));
    });*/

   
    

    maximize_button_ = new QPushButton;
    maximize_button_->setObjectName("maximize_button");
    maximize_button_->setFlat(true);
    maximize_button_->setFocusPolicy(Qt::NoFocus);
    connect(maximize_button_, &QPushButton::clicked, this, &MainForm::onMaximize_button_clicked);
   

    auto minimize_button = new QPushButton;
    minimize_button->setObjectName("minimize_button");
    minimize_button->setFlat(true);
    minimize_button->setFocusPolicy(Qt::NoFocus);

    connect(minimize_button, SIGNAL(clicked(bool)), this, SLOT(showMinimized()));

    auto title = new QLabel;

    title->installEventFilter(this);

    layout->addWidget(close_button);
    layout->addWidget(maximize_button_);
    layout->addWidget(minimize_button);
    layout->addWidget(title);
    //layout->addStretch();

    topNav->setLayout(layout);
    layout->setMargin(0);
    layout->setSpacing(0);

    return topNav;
}

QFrame* MainForm::create_nav()
{
    QFrame* nav = new QFrame;
    nav->setObjectName("nav");

    auto layout = new QVBoxLayout;


    auto logo = new QLabel;
    logo->setObjectName("logo");
    layout->addWidget(logo);

    auto space_widget = new QWidget;
    space_widget->setFixedHeight(50);

    layout->addWidget(space_widget);

    tool_button_parameter_ = createSidebarButton(":/images/celue_icon.svg", tr("参数"), "tool_button_Parameter");   
    tool_button_parameter_->setProperty("hover_icon", ":/images/celue_icon1.svg");
    layout->addWidget(tool_button_parameter_);


    tool_button_assets_ = createSidebarButton(":/images/zichan_icon.svg", tr("资产"), "tool_button_Assets");    
    tool_button_assets_->setProperty("hover_icon", ":/images/zichan_icon1.svg");
    layout->addWidget(tool_button_assets_);


    tool_button_log_ = createSidebarButton(":/images/rizhi_icon.svg", tr("日志"), "tool_button_Log");   
    tool_button_log_->setProperty("hover_icon", ":/images/rizhi_icon1.svg");
    layout->addWidget(tool_button_log_);   


    layout->addStretch();


    tool_button_logout_ = createSidebarButton(":/images/logout_icon.svg", tr("注销"), "tool_button_Logout");
    layout->addWidget(tool_button_logout_);

    auto space_widget2 = new QWidget;
    space_widget2->setFixedHeight(20);

    layout->addWidget(space_widget2);

    layout->setSpacing(0);
    layout->setMargin(0);

    nav->setLayout(layout);


    activeButton_ = tool_button_parameter_;
    activeButton_->setChecked(true);

    return nav;
}

QFrame* MainForm::create_nav2()
{
    QFrame* nav = new QFrame;
    nav->setObjectName("nav2");


    QWidget* nav2_top = new QWidget;
    nav2_top->setObjectName("nav2_top");
    auto nav2_top_layout = new QVBoxLayout;


    auto label = new QLabel;
    label->setText(u8"交易平台");

    auto combox1 = new QComboBox;
    combox1->addItem(u8"Bitstamp");
    auto combox2 = new QComboBox;
    combox2->addItem(u8"BTC_USD");

    auto chkCustom = new QCheckBox(u8"自定义");
    //chkCustom->setFixedWidth(80);


    QPushButton* button = new QPushButton(u8"添加");
    button->setObjectName("add_pair");


    auto ads_info = new QLabel;
    ads_info->setObjectName("ads_info");



    nav2_top_layout->addWidget(label);
    QHBoxLayout* layout1 = new QHBoxLayout;
    layout1->addWidget(combox1);
    layout1->addWidget(combox2);

    nav2_top_layout->addLayout(layout1);
    //nav2_top_layout->addWidget(chkCustom, Qt::AlignRight);
    nav2_top_layout->addWidget(chkCustom);
    nav2_top_layout->setAlignment(chkCustom, Qt::AlignRight);

    nav2_top_layout->addWidget(button);
    nav2_top_layout->addWidget(ads_info);

    nav2_top_layout->setAlignment(Qt::AlignTop);
    nav2_top_layout->setMargin(26);
    nav2_top_layout->setSpacing(16);


    nav2_top->setLayout(nav2_top_layout);


    QWidget* nav2_bottom = new QWidget;
    auto nav2_bottom_layout = new QVBoxLayout;


    auto label2 = new QLabel;
    label2->setText(u8"K线周期");

    auto combox3 = new QComboBox;
    combox3->addItem(u8"一分钟");


    QPushButton* button2 = new QPushButton(u8"运行机器人");
    button2->setObjectName("run_robot");


    auto label3 = new QLabel;
    label3->setText(u8"程序启动后");


    auto seconds = new QSpinBox;
    seconds->setSuffix(u8" 秒");
    seconds->setValue(10);

    auto chkAutoRun = new QCheckBox(u8"自动运行");


    nav2_bottom_layout->addWidget(label2);
    nav2_bottom_layout->addWidget(combox3);
    nav2_bottom_layout->addWidget(button2);

    nav2_bottom_layout->addWidget(label3);
    nav2_bottom_layout->addWidget(seconds);
    nav2_bottom_layout->addWidget(chkAutoRun);
    nav2_bottom_layout->setAlignment(chkAutoRun, Qt::AlignRight);

    QHBoxLayout* layout3 = new QHBoxLayout;

    auto small_button1 = new QPushButton(u8"默认");
    small_button1->setObjectName("small_button1");

    auto small_button2 = new QPushButton(u8"导出");
    small_button2->setObjectName("small_button2");

    auto small_button3 = new QPushButton(u8"导入");
    small_button3->setObjectName("small_button3");

    layout3->addWidget(small_button1);
    layout3->addWidget(small_button2);
    layout3->addWidget(small_button3);

    nav2_bottom_layout->addLayout(layout3);


    auto expire_label = new QLabel(u8"过期时间:2018-8-30 15:33:56");
    expire_label->setObjectName("expire_label");
    nav2_bottom_layout->addWidget(expire_label);
    nav2_bottom_layout->setAlignment(expire_label, Qt::AlignRight);

    nav2_bottom->setLayout(nav2_bottom_layout);

    nav2_bottom_layout->setAlignment(Qt::AlignTop);
    nav2_bottom_layout->setMargin(26);
    nav2_bottom_layout->setSpacing(16);




    QVBoxLayout* layout = new QVBoxLayout;   


    layout->addWidget(nav2_top);
    layout->addStretch();
    layout->addWidget(nav2_bottom);
   

    layout->setAlignment(Qt::AlignTop);
    layout->setMargin(0);
    layout->setSpacing(0);
    nav->setLayout(layout);
    return nav;
}

QFrame* MainForm::create_sub_main()
{
    QHBoxLayout* submain_layout = new QHBoxLayout;
    QFrame* submain = new QFrame;
    submain->setObjectName("submain");


    QFrame* nav2_ = create_nav2();
    nav2_->setObjectName("nav2");


    auto layout = new QVBoxLayout;
    QFrame* main2 = new QFrame;
    main2->setObjectName("main2");

    auto title = new QLabel(tr("简单均线策略"));
    title->setProperty("title", "true");


    auto tree = new QTreeWidget;
    tree->setObjectName("tree");
    tree->setHeaderHidden(true);
    auto root = new QTreeWidgetItem(tree);
    root->setText(0, tr("策略参数"));

    for (int i = 0; i < 10; ++i) {
        auto item = new QTreeWidgetItem(root);        
        auto item_layout = new QGridLayout;
        QWidget* pWidget = new QWidget;
       
        auto label = new QLabel(QString("参数%1").arg(i), pWidget);
        label->setProperty("is_arg", true);
        auto pDobleSpinBox = new QDoubleSpinBox(pWidget);
        pDobleSpinBox->setValue(10);
        item_layout->addWidget(label, 0, 0, 1, 1, Qt::AlignLeft);
        item_layout->addWidget(pDobleSpinBox, 0, 1, 1, 1, Qt::AlignLeft);
        item_layout->setColumnStretch(0, 1);
        item_layout->setColumnStretch(1, 5);
        pWidget->setLayout(item_layout);      
        tree->setItemWidget(item, 0, pWidget);
    }


    auto root2 = new QTreeWidgetItem(tree);
    root2->setText(0, tr("数字货币现货交易类库"));

    for (int i = 0; i < 15; ++i) {
        auto item = new QTreeWidgetItem(root2);
        auto item_layout = new QGridLayout;
        QWidget* pWidget = new QWidget;

        auto label = new QLabel(QString("参数%1").arg(i), pWidget);
        label->setProperty("is_arg", true);
        auto pDobleSpinBox = new QDoubleSpinBox(pWidget);
        pDobleSpinBox->setValue(10);
        item_layout->addWidget(label, 0, 0, 1, 1, Qt::AlignLeft);
        item_layout->addWidget(pDobleSpinBox, 0, 1, 1, 1, Qt::AlignLeft);
        item_layout->setColumnStretch(0, 1);
        item_layout->setColumnStretch(1, 5);
        pWidget->setLayout(item_layout);
        tree->setItemWidget(item, 0, pWidget);
    }

    tree->addTopLevelItem(root);
    tree->addTopLevelItem(root2);

    tree->expandAll();

    layout->addWidget(title);
    layout->addWidget(tree);

    layout->setAlignment(Qt::AlignTop);
    layout->setMargin(20);
    main2->setLayout(layout);

    submain_layout->addWidget(nav2_);
    submain_layout->addWidget(main2);
    submain_layout->setSpacing(0);
    submain_layout->setContentsMargins(0, 0, 0, 0);
   
    submain->setLayout(submain_layout);

    return submain;
}

QToolButton* MainForm::createSidebarButton(const QString& iconPath, const QString& title, const QString& object_name)
{
    QIcon icon(iconPath);
    QToolButton * btn = new QToolButton;
    btn->setIconSize(QSize(40, 40));
    btn->setText(title);
    btn->setToolButtonStyle(Qt::ToolButtonTextUnderIcon);
    btn->setFixedSize(84, 75);
    btn->setObjectName(object_name);
    btn->setCheckable(true);
    btn->setAutoRaise(false);
    btn->setProperty("default_icon", iconPath);
    QObject::connect(btn, SIGNAL(clicked(bool)),
        this, SLOT(changeCenterWidget(bool)));

    
    btn->setIcon(icon);
    

    return btn;
}
