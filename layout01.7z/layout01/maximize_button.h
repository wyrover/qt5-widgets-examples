#ifndef maximize_button_h__
#define maximize_button_h__


#ifndef CUSTOMPUSHBUTTON_H
#define CUSTOMPUSHBUTTON_H

#include <QPushButton>
#include <QEvent>
#include <QMouseEvent>
#include <QPainter>

class MaximizeButton : public QPushButton
{
    Q_OBJECT

public:
    explicit MaximizeButton(QWidget *parent = NULL);
    ~MaximizeButton() {}
    enum BtnStatus { NORMAL, PRESSED, HOVER };

    void setBtnBackground(const QString& path);
private:
    MaximizeButton(const MaximizeButton& obj);
    MaximizeButton& operator=(const MaximizeButton& obj);

protected:    
    void mousePressEvent(QMouseEvent *event);
    void mouseReleaseEvent(QMouseEvent *event);
    void enterEvent(QEvent* event);
    void leaveEvent(QEvent* event);

private:
    BtnStatus m_status;  // record the status to take different painting action
    bool isPressed;   // whether the button is pressed.    
};

#endif // CUSTOMPUSHBUTTON_H


#endif // maximize_button_h__
