﻿#if defined (_MSC_VER) && (_MSC_VER >=1600)
#pragma execution_character_set("utf-8")
#endif


#include "loginform.h"
#include "ui_loginform.h"
#include <QVBoxLayout>
#include <QLabel>
#include <QCheckBox>
#include <QPushButton>
#include <QFrame>
#include <QComboBox>
#include <QDebug>

LoginForm::LoginForm(QWidget *parent) :
    DropShadowWidget(parent)    
{
    
   
    auto layout_shadow = new QVBoxLayout;
    auto layout = new QVBoxLayout;
    auto widget = new QWidget;
    widget->setObjectName("loginform");


    QFrame* topNav = new QFrame;
    topNav->setObjectName("topNav");

    auto title_layout = new QHBoxLayout;
    title_layout->setDirection(QBoxLayout::RightToLeft);

    auto close_button = new QPushButton;
    close_button->setObjectName("close_button");
    close_button->setFlat(true);
    close_button->setFocusPolicy(Qt::NoFocus);
    auto minimize_button = new QPushButton;
    minimize_button->setObjectName("minimize_button");
    close_button->setFlat(true);
    close_button->setFocusPolicy(Qt::NoFocus);
    connect(close_button, &QPushButton::clicked, [=](bool checked) {
        this->close();
    });


    title_layout->addWidget(close_button);
    title_layout->addWidget(minimize_button);
    title_layout->setMargin(0);
    title_layout->setSpacing(0);
    topNav->setLayout(title_layout);


    auto frame = new QFrame;
    frame->setObjectName("frame");
    auto frame_layout = new QVBoxLayout;
    


    auto logo = new QLabel;
    logo->setObjectName("login_logo");


    auto btnLanguage = new QPushButton;
    btnLanguage->setObjectName("btnLanguage");
    btnLanguage->setCheckable(true);    
    connect(btnLanguage, &QPushButton::clicked, [=](bool checked) {
        qDebug() << (checked ? "english" : "Zh_cn");
    });

   
    auto chkAutoLogin = new QCheckBox;
    chkAutoLogin->setObjectName("chkAutoLogin");
    chkAutoLogin->setText(tr("10 秒后自动登录"));



    frame_layout->addWidget(logo, 0, Qt::AlignHCenter);
    frame_layout->addWidget(create_custom_combox(), 0, Qt::AlignHCenter);
    frame_layout->addWidget(btnLanguage, 0, Qt::AlignHCenter);
    frame_layout->addWidget(chkAutoLogin, 0, Qt::AlignRight);


    auto layout1 = new QHBoxLayout;
    
    auto btnLogin = new QPushButton(tr("登录"));
    btnLogin->setObjectName("btnLogin");
    auto btnCancel = new QPushButton(tr("取消"));
    btnCancel->setObjectName("btnCancel");

    layout1->addWidget(btnLogin);
    layout1->addWidget(btnCancel);
    layout1->setSpacing(20);
    frame_layout->addLayout(layout1);
    frame_layout->setAlignment(Qt::AlignTop);
    frame->setLayout(frame_layout);

    layout->addWidget(topNav, 0, Qt::AlignRight);
    layout->addWidget(frame, 0, Qt::AlignHCenter);
    layout->setMargin(0);

    widget->setLayout(layout);
    layout_shadow->addWidget(widget);
   
    layout_shadow->setContentsMargins(4, 4, 4, 4);   
    setLayout(layout_shadow);

    resize(770, 528);
    
}

LoginForm::~LoginForm()
{
    
}

QWidget* LoginForm::create_custom_combox()
{
    auto widget = new QWidget;
    widget->setObjectName("custom_combox");
    auto layout = new QHBoxLayout;

    auto label = new QLabel;
    label->setObjectName("combox_label");
    label->setFixedWidth(50);

    auto line = new QWidget;
    line->setObjectName("combox_line");
    

    auto combox = new QComboBox;
    combox->setObjectName("combox_combox");
    combox->addItem(tr("test1"));
    combox->addItem(tr("test2"));
    //combox->setFixedWidth()

    layout->addWidget(label);
    layout->addWidget(line);
    layout->addWidget(combox);
    //layout->addStretch();

    layout->setMargin(0);
    layout->setSpacing(0);
    widget->setLayout(layout);
    return widget;    
}
