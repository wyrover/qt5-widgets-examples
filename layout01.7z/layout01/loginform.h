#ifndef DIALOG_H
#define DIALOG_H

#include "drop_shadow_widget.h"
#include <QDialog>
#include <QWidget>


class LoginForm : public DropShadowWidget
{
    Q_OBJECT

public:
    explicit LoginForm(QWidget *parent = 0);
    ~LoginForm();

private:
    QWidget* create_custom_combox();

private:
    QWidget* custom_combox_;

};

#endif // DIALOG_H
