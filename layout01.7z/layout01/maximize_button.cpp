#include "maximize_button.h"

MaximizeButton::MaximizeButton(QWidget *parent)
    : QPushButton(parent)
{

}



void MaximizeButton::mousePressEvent(QMouseEvent *event)
{
    // only when the left button is pressed we force the repaint
    if (event->button() == Qt::LeftButton) {
        isPressed = true;
        m_status = PRESSED;
        update();
    }
}

void MaximizeButton::mouseReleaseEvent(QMouseEvent *event)
{
    if (event->button() == Qt::LeftButton && isPressed) {
        isPressed = false;
        m_status = NORMAL;
        emit clicked();
    }
}

void MaximizeButton::enterEvent(QEvent* event)
{
    isPressed = false;
    m_status = HOVER;
    this->setIcon(QIcon(":/images/closs_icon_1.svg"));
}

void MaximizeButton::leaveEvent(QEvent* event)
{
    isPressed = false;
    m_status = NORMAL;
    this->setIcon(QIcon(":/images/closs_icon.svg"));
}

